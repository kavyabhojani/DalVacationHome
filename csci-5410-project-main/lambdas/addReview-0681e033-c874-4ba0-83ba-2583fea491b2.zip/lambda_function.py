import json
import boto3
import uuid

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('RoomReviews')

def lambda_handler(event, context):
    room_id = event.get('id')
    review = event.get('review')
    rating = event.get('rating')
    
    if not room_id or not review or rating is None:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing parameters'}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
    
    review_id = str(uuid.uuid4())
    
    table.put_item(
        Item={
            'room_id': room_id,
            'review_id': review_id,
            'review': review,
            'rating': rating
        }
    )
    
    return {
        'statusCode': 201,
        'body': json.dumps({'review_id': review_id}),
        'headers': {
            'Content-Type': 'application/json'
        }
    }
