import json
import boto3

dynamo_db = boto3.client('dynamodb')

def lambda_handler(event, context):
    try:
        response = dynamo_db.scan(TableName='Rooms')
        items = response['Items']

        rooms = []
        for item in items:
            room = {}
            for key, value in item.items():
                room[key] = list(value.values())[0]
            rooms.append(room)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
            },
            'body': json.dumps(rooms),
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
            },
            'body': json.dumps({'error': str(e)})
        }
