import json
import boto3
from uuid import uuid4

dynamo_db = boto3.client('dynamodb')

def lambda_handler(event, context):
    try:
        print("Received event:", event)
        data = event
        
        required_fields = ['name', 'price', 'description', 'photo', 'amenities', 'type']
        for field in required_fields:
            if field not in data:
                raise ValueError(f"Missing required field: {field}")
        
        room_id = str(uuid4())
        
        item = {
            'roomId': {'S': room_id},
            'name': {'S': data['name']},
            'price': {'N': str(data['price'])},
            'description': {'S': data['description']},
            'photo': {'S': data['photo']},
            'amenities': {'L': [{'S': amenity} for amenity in data['amenities']]},
            'type': {'S': data['type']}
        }
        
        try:
            dynamo_db.put_item(TableName='Rooms', Item=item)
            return {
                'statusCode': 200,
                'body': json.dumps({'id': room_id})
            }
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({'error': str(e)})
            }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(e)})
        }
