import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('DalUsers')
sns = boto3.client('sns')
userNotificationTopicArn = 'arn:aws:sns:us-east-1:817321140247:UserNotificationTopic'

def decrypt(text, shift):
    decrypted_text = []
    for char in text:
        if char.isalpha():
            shift_base = 65 if char.isupper() else 97
            decrypted_text.append(chr((ord(char) - shift_base - shift) % 26 + shift_base))
        else:
            decrypted_text.append(char)
    return ''.join(decrypted_text)

def lambda_handler(event, context):
    body = json.loads(event['body'])
    user_id = body['userId']
    cipher_text = body['cipherText']
    user_answer = body['userAnswer']

    try:
        response = table.get_item(
            Key={
                'UserID': user_id,
            }
        )
        if 'Item' not in response:
            raise ValueError('User not found')

        cipher_key = int(response['Item']['CipherKey'])
        decrypted_text = decrypt(cipher_text, cipher_key)

        if user_answer == decrypted_text:
            # Send a notification email on successful verification
            try:
                sns.publish(
                    TopicArn=userNotificationTopicArn,
                    Message='You have been logged in successfully, User ID: {user_id}',
                    Subject='Login Success Notification',
                    MessageStructure='json'
                )
            except ClientError as e:
                print(f"Failed to send SNS notification: {str(e)}")

            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Caesar cipher verified successfully'})
            }
        else:
            return {
                'statusCode': 401,
                'body': json.dumps({'message': 'Incorrect decryption'})
            }
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Error verifying Caesar cipher', 'error': str(e)})
        }
    except ValueError as e:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': str(e)})
        }
