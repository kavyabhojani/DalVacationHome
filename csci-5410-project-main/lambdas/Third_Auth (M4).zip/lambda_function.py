import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('DalUsers')
sns = boto3.client('sns')
userNotificationTopicArn = 'arn:aws:sns:us-east-1:817321140247:UserNotificationTopic'

def is_email_subscribed(email, topic_arn):
    next_token = None
    while True:
        params = {
            'TopicArn': topic_arn,
        }
        if next_token:
            params['NextToken'] = next_token

        response = sns.list_subscriptions_by_topic(**params)
        subscriptions = response.get('Subscriptions', [])

        for subscription in subscriptions:
            if subscription['Endpoint'] == email:
                if subscription['SubscriptionArn'] == 'PendingConfirmation':
                    return False
                return True

        next_token = response.get('NextToken')
        if not next_token:
            break
    return False

def lambda_handler(event, context):
    body = json.loads(event['body'])
    user_id = body['userId']
    cipher_key = body['cipherKey']
    email = body['userId']

    try:
        # Update the DynamoDB table with the cipher key
        response = table.update_item(
            Key={
                'UserID': user_id,
            },
            UpdateExpression="SET CipherKey = :key",
            ExpressionAttributeValues={
                ':key': cipher_key,
            },
            ReturnValues="UPDATED_NEW"
        )

        # Check if the email is already subscribed and confirmed
        if not is_email_subscribed(email, userNotificationTopicArn):
            # Subscribe the user's email to the SNS topic
            try:
                subscribe_response = sns.subscribe(
                    Protocol='email',
                    TopicArn=userNotificationTopicArn,
                    Endpoint=email,
                    ReturnSubscriptionArn=True
                )
                subscription_arn = subscribe_response['SubscriptionArn']
                if subscription_arn == 'PendingConfirmation':
                    print(f"Subscription confirmation email sent to {email}. Awaiting confirmation.")
                else:
                    print(f"Subscribed {email} to {userNotificationTopicArn} with subscription ARN {subscription_arn}")
            except ClientError as e:
                print(f"Failed to subscribe {email} to {userNotificationTopicArn}: {str(e)}")
                return {
                    'statusCode': 500,
                    'body': json.dumps({'message': 'Failed to subscribe email to notifications', 'error': str(e)})
                }
        else:
            print(f"{email} is already subscribed and confirmed to {userNotificationTopicArn}")

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Cipher key stored successfully  ', 'updatedAttributes': response['Attributes']})
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Failed to store cipher key', 'error': str(e)})
        }
