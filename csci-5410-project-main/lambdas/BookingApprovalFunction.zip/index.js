const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();

const tableName = 'Reservations';
const userNotificationTopicArn = 'arn:aws:sns:us-east-1:817321140247:UserNotificationTopic';

exports.handler = async (event) => {
    console.log('Event received:', JSON.stringify(event, null, 2));

    for (const record of event.Records) {
        try {
            const snsMessage = JSON.parse(record.body);
            const message = JSON.parse(snsMessage.Message);
            console.log('Message received:', message);

            const { reservation_id, user_id, room_id, start_date, end_date, status } = message;

            // Check for undefined values
            if (!reservation_id || !user_id || !room_id || !start_date || !end_date) {
                throw new Error('Missing required fields in the message');
            }

            // Retrieve existing bookings for the same room and check for date overlap
            const params = {
                TableName: tableName,
                FilterExpression: '#room_id = :room_id AND #status = :approved AND ((:start_date BETWEEN #start_date AND #end_date) OR (:end_date BETWEEN #start_date AND #end_date) OR (#start_date BETWEEN :start_date AND :end_date) OR (#end_date BETWEEN :start_date AND :end_date))',
                ExpressionAttributeNames: {
                    '#room_id': 'room_id',
                    '#start_date': 'start_date',
                    '#end_date': 'end_date',
                    '#status': 'status'
                },
                ExpressionAttributeValues: {
                    ':room_id': room_id,
                    ':start_date': start_date,
                    ':end_date': end_date,
                    ':approved': 'approved'
                }
            };

            const existingBookings = await dynamodb.scan(params).promise();
            let bookingStatus = 'approved';

            if (existingBookings.Items.length > 0) {
                bookingStatus = 'rejected';
            }

            // Update the booking status in DynamoDB
            const updateParams = {
                TableName: tableName,
                Key: { reservation_id: reservation_id },
                UpdateExpression: 'set #status = :status',
                ExpressionAttributeNames: { '#status': 'status' },
                ExpressionAttributeValues: { ':status': bookingStatus }
            };
            await dynamodb.update(updateParams).promise();
            console.log(`Booking ${reservation_id} updated with status ${bookingStatus}`);


            // Send notification to user via SNS
            const snsParams = {
                Subject: 'Room Booking Status Update',
                Message: `Your booking for room ${room_id} from ${start_date} to ${end_date} has been ${bookingStatus}.`,
                TopicArn: userNotificationTopicArn
            };

            await sns.publish(snsParams).promise();
            console.log(`Notification sent to ${email}`);
        } catch (error) {
            console.error('Error processing booking request:', error);
        }
    }
};
