import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('DalUsers')

def lambda_handler(event, context):
    body = json.loads(event['body'])
    user_id = body['userId']
    question_id = body['questionId']
    answer = body['answer']
    
    try:
        response = table.get_item(Key={'UserID': user_id})
        if 'Item' in response:
            user_data = response['Item']
            question_ids = user_data['SecurityQuestionIds']
            answers = user_data['SecurityAnswers']
            index = question_ids.index(question_id)
            if answers[index] == answer:
                return {
                    'statusCode': 200,
                    'body': json.dumps({'message': 'Security question verified successfully'})
                }
        return {
            'statusCode': 401,
            'body': json.dumps({'message': 'Incorrect answer'})
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Failed to verify security question', 'error': str(e)})
        }
