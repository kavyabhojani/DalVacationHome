import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Rooms')

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    room_id = event.get('id', None)
    
    if room_id is None:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing room ID'}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
    
    try:
        response = table.get_item(Key={'roomId': room_id})
        room = response.get('Item', {})
        
        return {
            'statusCode': 200,
            'body': json.dumps(room, cls=DecimalEncoder),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
