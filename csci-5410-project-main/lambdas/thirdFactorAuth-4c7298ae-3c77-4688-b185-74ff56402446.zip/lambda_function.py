import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('DalUsers')

def lambda_handler(event, context):
    body = json.loads(event['body'])
    user_id = body['userId']
    cipher_key = body['cipherKey']
    
    try:
        response = table.update_item(
            Key={
                'UserID': user_id,
            },
            UpdateExpression="SET CipherKey = :key",
            ExpressionAttributeValues={
                ':key': cipher_key,
            },
            ReturnValues="UPDATED_NEW"
        )
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Cipher key stored successfully', 'updatedAttributes': response['Attributes']})
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Failed to store cipher key', 'error': str(e)})
        }
