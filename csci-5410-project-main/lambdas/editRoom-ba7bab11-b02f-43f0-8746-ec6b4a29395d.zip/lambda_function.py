import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Rooms')

def lambda_handler(event, context):
    try:
        room_id = event.get('roomId')
        if not room_id:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Room ID is required'})
            }
        
        update_expression = 'SET '
        expression_attribute_values = {}
        expression_attribute_names = {}
        
        if 'name' in event:
            update_expression += '#name = :name, '
            expression_attribute_values[':name'] = event['name']
            expression_attribute_names['#name'] = 'name'
        if 'price' in event:
            update_expression += 'price = :price, '
            expression_attribute_values[':price'] = event['price']
        if 'description' in event:
            update_expression += 'description = :description, '
            expression_attribute_values[':description'] = event['description']
        if 'photo' in event:
            update_expression += 'photo = :photo, '
            expression_attribute_values[':photo'] = event['photo']
        if 'amenities' in event:
            update_expression += 'amenities = :amenities, '
            expression_attribute_values[':amenities'] = event['amenities']
        if 'type' in event:
            update_expression += '#type = :type, '
            expression_attribute_values[':type'] = event['type']
            expression_attribute_names['#type'] = 'type'
        
        if update_expression.endswith(', '):
            update_expression = update_expression[:-2]
        
        response = table.update_item(
            Key={'roomId': room_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ExpressionAttributeNames=expression_attribute_names
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Room updated successfully'})
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
