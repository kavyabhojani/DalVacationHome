import json
import boto3
from boto3.dynamodb.conditions import Key
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('RoomReviews')

def decimal_to_float(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError

def lambda_handler(event, context):
    room_id = event.get('id')
    
    if not room_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing room_id parameter'}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
    
    response = table.query(
        KeyConditionExpression=Key('room_id').eq(room_id)
    )
    reviews = response.get('Items', [])

    return {
        'statusCode': 200,
        'body': json.dumps(reviews, default=decimal_to_float),
        'headers': {
            'Content-Type': 'application/json'
        }
    }
