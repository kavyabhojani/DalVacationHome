import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('DalUsers')

def lambda_handler(event, context):
    print("Received event: ", event)
    
    try:
        body = json.loads(event['body'])
        print("Parsed body: ", body)
        
        user_id = body['userId']
        question_ids = body['questions']
        answers = body['answers']
        
        print("User ID: ", user_id)
        print("Question IDs: ", question_ids)
        print("Answers: ", answers)
        
        response = table.put_item(
            Item={
                'UserID': user_id,
                'SecurityQuestionIds': question_ids,
                'SecurityAnswers': answers
            }
        )
        
        print("DynamoDB Response: ", response)
        
        stored_item = table.get_item(Key={'UserID': user_id})
        print("Stored item: ", stored_item)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Security questions stored successfully'})
        }
    except json.JSONDecodeError as e:
        print("JSON Decode Error: ", str(e))
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid JSON format', 'error': str(e)})
        }
    except ClientError as e:
        print("Client Error: ", e.response['Error']['Message'])
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Failed to store security questions', 'error': e.response['Error']['Message']})
        }
    except Exception as e:
        print("Unexpected Error: ", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'An unexpected error occurred', 'error': str(e)})
        }
