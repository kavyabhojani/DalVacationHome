import json
import boto3
import uuid

dynamodb = boto3.resource('dynamodb')
reservations_table = dynamodb.Table('Reservations')
sns = boto3.client('sns')

# Replace with your SNS topic ARN
sns_topic_arn = 'arn:aws:sns:us-east-1:817321140247:RoomBookingRequestTopic'


def lambda_handler(event, context):
    user_id = event['user_id']
    room_id = event['room_id']
    start_date = event['start_date']
    end_date = event['end_date']
    status = 'pending'

    reservation_id = str(uuid.uuid4())

    # Add the booking request to the DynamoDB table
    reservations_table.put_item(
        Item={
            'reservation_id': reservation_id,
            'user_id': user_id,
            'room_id': room_id,
            'start_date': start_date,
            'end_date': end_date,
            'status': status,
        }
    )

    # Create the message payload for SNS
    message = {
        'reservation_id': reservation_id,
        'user_id': user_id,
        'room_id': room_id,
        'start_date': start_date,
        'end_date': end_date,
        'status': status,
    }

    # Publish the message to the SNS topic
    sns.publish(
        TopicArn=sns_topic_arn,
        Message=json.dumps({'default': json.dumps(message)}),
        MessageStructure='json',
        Subject='Room Booking Request'
    )

    return {
        'statusCode': 201,
        'body': json.dumps({'reservation_id': reservation_id}),
        'headers': {
            'Content-Type': 'application/json'
        }
    }
